/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EMT;

/**
 *
 * @author danylee
 */
public interface ExamenInt {
    public String getHoyNoCircula();
    public String getByPlaca(String t);
    public String getTerminacionPlaca(String t);
    public String getColor(String t);
    
    
    
    
    
    
}
